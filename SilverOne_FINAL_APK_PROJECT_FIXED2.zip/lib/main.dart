import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_xprinter_sdk/flutter_xprinter_sdk.dart';

const supabaseUrl = 'https://pkhxvxjtxkzdujpppnmj.supabase.co';
const supabaseKey = 'sb_publishable_lVBLKTFPy9atxKOzb-gDKQ_VXpQNQM1';
final sb = Supabase.instance.client;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, publishableKey: supabaseKey);
  runApp(const SilverOneApp());
}

class SilverOneApp extends StatelessWidget {
  const SilverOneApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Silver One',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xff5b5f66),
        scaffoldBackgroundColor: const Color(0xfff6f7f9),
      ),
      home: const Root(),
    );
  }
}

class Root extends StatelessWidget {
  const Root({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: sb.auth.onAuthStateChange,
      builder: (context, snapshot) {
        final loggedIn =
            snapshot.data?.session != null || sb.auth.currentSession != null;
        return loggedIn ? const MainShell() : const LoginPage();
      },
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: tab,
        children: const [
          Home(),
          SalesPage(),
          ReportsPage(),
          InvoicesPage(),
          SettingsPage(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'الرئيسية',
          ),
          NavigationDestination(
            icon: Icon(Icons.point_of_sale_outlined),
            selectedIcon: Icon(Icons.point_of_sale),
            label: 'المبيعات',
          ),
          NavigationDestination(
            icon: Icon(Icons.bar_chart_outlined),
            selectedIcon: Icon(Icons.bar_chart),
            label: 'التقارير',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long),
            label: 'الفواتير',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings),
            label: 'الإعدادات',
          ),
        ],
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginState();
}

class _LoginState extends State<LoginPage> {
  final e = TextEditingController();
  final p = TextEditingController();
  bool loading = false;
  String? err;

  Future<void> login() async {
    setState(() => loading = true);
    try {
      await sb.auth.signInWithPassword(
        email: e.text.trim(),
        password: p.text,
      );
      if (mounted) setState(() {});
    } catch (x) {
      if (mounted) setState(() => err = x.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> signup() async {
    setState(() => loading = true);
    try {
      await sb.auth.signUp(email: e.text.trim(), password: p.text);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم إنشاء الحساب.')),
        );
      }
    } catch (x) {
      if (mounted) setState(() => err = x.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext c) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.diamond, size: 64),
                    const SizedBox(height: 8),
                    const Text(
                      'Silver One',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: e,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        labelText: 'البريد الإلكتروني',
                        prefixIcon: Icon(Icons.email),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: p,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'كلمة المرور',
                        prefixIcon: Icon(Icons.lock),
                      ),
                    ),
                    if (err != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(
                          err!,
                          style: const TextStyle(color: Colors.red),
                        ),
                      ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: loading ? null : login,
                        child: Text(loading ? '...' : 'دخول'),
                      ),
                    ),
                    TextButton(
                      onPressed: loading ? null : signup,
                      child: const Text('إنشاء حساب جديد'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext c) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            title: const Text('Silver One'),
            floating: true,
            actions: [
              IconButton(
                onPressed: () => Navigator.push(
                  c,
                  MaterialPageRoute(builder: (_) => const ScannerPage()),
                ),
                icon: const Icon(Icons.qr_code_scanner),
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: FutureBuilder(
              future: sb
                  .from('products')
                  .select('category,qty,weight,active')
                  .eq('active', true),
              builder: (c, s) {
                if (!s.hasData) {
                  return const Padding(
                    padding: EdgeInsets.all(20),
                    child: CircularProgressIndicator(),
                  );
                }
                final rows = s.data as List;
                final silver = rows
                    .where((x) => x['category'] == 'silver')
                    .fold<int>(0, (a, x) => a + ((x['qty'] as num?)?.toInt() ?? 0));
                final weight = rows
                    .where((x) => x['category'] == 'silver')
                    .fold<double>(
                      0,
                      (a, x) =>
                          a +
                          ((x['weight'] as num?)?.toDouble() ?? 0) *
                              ((x['qty'] as num?)?.toInt() ?? 0),
                    );
                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      StatCard('قطع الفضة', silver.toString(), Icons.diamond),
                      StatCard(
                        'وزن الفضة',
                        '${weight.toStringAsFixed(2)} غ',
                        Icons.scale,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverGrid(
              delegate: SliverChildListDelegate([
                Tile(
                  'فضة',
                  Icons.diamond,
                  () => Navigator.push(
                    c,
                    MaterialPageRoute(
                      builder: (_) =>
                          const ProductsPage(category: 'silver', title: 'الفضة'),
                    ),
                  ),
                ),
                Tile(
                  'ساعات',
                  Icons.watch,
                  () => Navigator.push(
                    c,
                    MaterialPageRoute(
                      builder: (_) => const ProductsPage(
                        category: 'watches',
                        title: 'الساعات',
                      ),
                    ),
                  ),
                ),
                Tile(
                  'عطور',
                  Icons.local_florist,
                  () => Navigator.push(
                    c,
                    MaterialPageRoute(
                      builder: (_) => const ProductsPage(
                        category: 'perfumes',
                        title: 'العطور',
                      ),
                    ),
                  ),
                ),
                Tile(
                  'عام',
                  Icons.inventory_2,
                  () => Navigator.push(
                    c,
                    MaterialPageRoute(builder: (_) => const GeneralSalePage()),
                  ),
                ),
              ]),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.1,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  final String a;
  final String b;
  final IconData i;

  const StatCard(this.a, this.b, this.i, {super.key});

  @override
  Widget build(BuildContext c) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Icon(i, size: 30),
              Text(a),
              Text(
                b,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Tile extends StatelessWidget {
  final String t;
  final IconData i;
  final VoidCallback f;

  const Tile(this.t, this.i, this.f, {super.key});

  @override
  Widget build(BuildContext c) {
    return Card(
      child: InkWell(
        onTap: f,
        borderRadius: BorderRadius.circular(16),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(i, size: 44),
              const SizedBox(height: 8),
              Text(
                t,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ProductsPage extends StatefulWidget {
  final String category;
  final String title;

  const ProductsPage({
    required this.category,
    required this.title,
    super.key,
  });

  @override
  State<ProductsPage> createState() => _ProductsState();
}

class _ProductsState extends State<ProductsPage> {
  List rows = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await sb
          .from('products')
          .select('*')
          .eq('category', widget.category)
          .eq('active', true)
          .order('created_at');
      if (!mounted) return;
      setState(() {
        rows = r;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تحميل الأصناف: $e')),
      );
    }
  }

  Future<void> add() async {
    final name = TextEditingController();
    final type = TextEditingController();
    final weight = TextEditingController();
    final price = TextEditingController();
    final qty = TextEditingController(text: '1');
    String typ = widget.category == 'silver' ? 'ستاتي' : '';

    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text('إضافة ${widget.title}'),
        content: Directionality(
          textDirection: TextDirection.rtl,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: name,
                  decoration: const InputDecoration(labelText: 'اسم الصنف'),
                ),
                if (widget.category == 'silver')
                  DropdownButtonFormField<String>(
                    initialValue: typ,
                    items: const [
                      DropdownMenuItem(
                        value: 'ستاتي',
                        child: Text('ستاتي — 6 د/غ'),
                      ),
                      DropdownMenuItem(
                        value: 'رجالي',
                        child: Text('رجالي — 5 د/غ'),
                      ),
                    ],
                    onChanged: (v) {
                      if (v != null) typ = v;
                    },
                    decoration: const InputDecoration(labelText: 'النوع'),
                  ),
                if (widget.category == 'silver')
                  TextField(
                    controller: weight,
                    keyboardType: TextInputType.number,
                    decoration:
                        const InputDecoration(labelText: 'الوزن بالغرام'),
                  ),
                if (widget.category != 'silver')
                  TextField(
                    controller: type,
                    decoration: const InputDecoration(labelText: 'النوع'),
                  ),
                TextField(
                  controller: price,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: widget.category == 'silver'
                        ? 'السعر (تلقائي)'
                        : 'السعر',
                  ),
                ),
                TextField(
                  controller: qty,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'الكمية'),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    final w = double.tryParse(weight.text) ?? 0;
    final q = int.tryParse(qty.text) ?? 0;
    final pr = widget.category == 'silver'
        ? w * (typ == 'رجالي' ? 5 : 6)
        : (double.tryParse(price.text) ?? 0);

    if (name.text.trim().isEmpty || q <= 0 || pr <= 0) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('أدخل بيانات الصنف بشكل صحيح.')),
        );
      }
      return;
    }

    try {
      final code = await sb.rpc(
        'next_product_code',
        params: {'p_category': widget.category},
      );
      await sb.from('products').insert({
        'code': code,
        'category': widget.category,
        'name': name.text.trim(),
        'type': widget.category == 'silver' ? typ : type.text.trim(),
        'weight': widget.category == 'silver' ? w : null,
        'price': pr,
        'qty': q,
        'total': q,
        'active': true,
      });
      await load();
      await Printer.printLabel(
        code.toString(),
        name.text.trim(),
        widget.category == 'silver' ? w : null,
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر حفظ الصنف: $e')),
        );
      }
    }
  }

  Future<void> sell(Map x) async {
    try {
      await sb.rpc(
        'create_sale',
        params: {
          'p_items': [
            {
              'product_id': x['id'],
              'qty': 1,
              'price': x['price'],
            },
          ],
          'p_total': x['price'],
          'p_discount': 0,
        },
      );
      await load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم البيع وإنشاء الفاتورة')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر البيع: $e')),
        );
      }
    }
  }

  Future<void> remove(Map x) async {
    try {
      await sb.from('products').update({'active': false}).eq('id', x['id']);
      await load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر حذف الصنف: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext c) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(c),
          ),
          actions: [
            IconButton(onPressed: add, icon: const Icon(Icons.add)),
          ],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: load,
                child: ListView.builder(
                  itemCount: rows.length,
                  itemBuilder: (c, i) {
                    final x = rows[i];
                    return Card(
                      child: ListTile(
                        title: Text('${x['name']}  •  ${x['code']}'),
                        subtitle: Text(
                          '${x['type'] ?? ''}  |  الكمية: ${x['qty']}  |  السعر: ${x['price']}',
                        ),
                        trailing: PopupMenuButton<String>(
                          itemBuilder: (_) => const [
                            PopupMenuItem(
                              value: 'sell',
                              child: Text('بيع قطعة'),
                            ),
                            PopupMenuItem(
                              value: 'delete',
                              child: Text('حذف'),
                            ),
                          ],
                          onSelected: (v) async {
                            if (v == 'sell') {
                              await sell(x);
                            } else {
                              await remove(x);
                            }
                          },
                        ),
                      ),
                    );
                  },
                ),
              ),
      ),
    );
  }
}

class ScannerPage extends StatefulWidget {
  const ScannerPage({super.key});

  @override
  State<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends State<ScannerPage> {
  bool ready = false;
  String? error;

  @override
  void initState() {
    super.initState();
    _requestCamera();
  }

  Future<void> _requestCamera() async {
    final status = await Permission.camera.request();
    if (!mounted) return;
    if (status.isGranted) {
      setState(() => ready = true);
    } else {
      setState(() => error = 'يجب السماح باستخدام الكاميرا لمسح الباركود.');
    }
  }

  @override
  Widget build(BuildContext c) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مسح الباركود'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(c),
        ),
      ),
      body: error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(error!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: _requestCamera,
                      child: const Text('السماح بالكاميرا'),
                    ),
                  ],
                ),
              ),
            )
          : ready
              ? MobileScanner(
                  onDetect: (capture) {
                    if (capture.barcodes.isEmpty) return;
                    final code = capture.barcodes.first.rawValue;
                    if (code != null && code.isNotEmpty) {
                      Navigator.pop(c, code);
                    }
                  },
                )
              : const Center(child: CircularProgressIndicator()),
    );
  }
}

class GeneralSalePage extends StatefulWidget {
  const GeneralSalePage({super.key});

  @override
  State<GeneralSalePage> createState() => _GeneralState();
}

class _GeneralState extends State<GeneralSalePage> {
  final price = TextEditingController();
  String type = 'ذبل ستانلس';

  Future<void> registerSale() async {
    final p = double.tryParse(price.text) ?? 0;
    if (p <= 0) return;

    try {
      await sb.rpc(
        'create_sale',
        params: {
          'p_items': [
            {
              'product_id': null,
              'qty': 1,
              'price': p,
              'code': 'GENERAL',
              'name': type,
              'type': type,
            },
          ],
          'p_total': p,
          'p_discount': 0,
        },
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر تسجيل البيع: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext c) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('بيع عام'),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(c),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              DropdownButtonFormField<String>(
                initialValue: type,
                items: const [
                  'ذبل ستانلس',
                  'علب',
                  'بطاريات',
                ]
                    .map(
                      (x) => DropdownMenuItem<String>(
                        value: x,
                        child: Text(x),
                      ),
                    )
                    .toList(),
                onChanged: (v) {
                  if (v != null) setState(() => type = v);
                },
                decoration: const InputDecoration(labelText: 'النوع'),
              ),
              TextField(
                controller: price,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'السعر'),
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: registerSale,
                child: const Text('تسجيل البيع'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SalesPage extends StatelessWidget {
  const SalesPage({super.key});

  @override
  Widget build(BuildContext c) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('المبيعات')),
        body: FutureBuilder(
          future: sb
              .from('invoices')
              .select('invoice_no,total,discount,created_at')
              .order('created_at', ascending: false),
          builder: (c, s) {
            if (!s.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final r = s.data as List;
            return ListView.builder(
              itemCount: r.length,
              itemBuilder: (c, i) {
                final created = DateTime.parse(r[i]['created_at']).toLocal();
                return ListTile(
                  title: Text('${r[i]['invoice_no']}'),
                  subtitle: Text(DateFormat('yyyy-MM-dd HH:mm').format(created)),
                  trailing: Text('${r[i]['total']} د.أ'),
                );
              },
            );
          },
        ),
      ),
    );
  }
}

class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key});

  @override
  Widget build(BuildContext c) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('التقارير')),
        body: FutureBuilder(
          future: Future.wait([
            sb.from('invoices').select('total,created_at'),
            sb.from('expenses').select('amount,created_at'),
          ]),
          builder: (c, s) {
            if (!s.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final a = s.data![0] as List;
            final e = s.data![1] as List;
            final sales = a.fold<double>(
              0,
              (v, x) => v + ((x['total'] as num?)?.toDouble() ?? 0),
            );
            final exp = e.fold<double>(
              0,
              (v, x) => v + ((x['amount'] as num?)?.toDouble() ?? 0),
            );
            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                StatCard(
                  'إجمالي المبيعات',
                  '${sales.toStringAsFixed(2)} د.أ',
                  Icons.trending_up,
                ),
                StatCard(
                  'المصروفات',
                  '${exp.toStringAsFixed(2)} د.أ',
                  Icons.money_off,
                ),
                StatCard(
                  'صافي المبيعات',
                  '${(sales - exp).toStringAsFixed(2)} د.أ',
                  Icons.account_balance_wallet,
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class InvoicesPage extends StatelessWidget {
  const InvoicesPage({super.key});

  @override
  Widget build(BuildContext context) => const SalesPage();
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext c) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('الإعدادات')),
        body: ListView(
          children: [
            ListTile(
              leading: const Icon(Icons.print),
              title: const Text('اختبار HP6'),
              onTap: () async {
                try {
                  await Printer.test();
                } catch (e) {
                  if (c.mounted) {
                    ScaffoldMessenger.of(c).showSnackBar(
                      SnackBar(content: Text('تعذر اختبار الطابعة: $e')),
                    );
                  }
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.bluetooth),
              title: const Text('ربط HP6'),
              onTap: () async {
                try {
                  await Printer.connect();
                  if (c.mounted) {
                    ScaffoldMessenger.of(c).showSnackBar(
                      const SnackBar(content: Text('تم ربط HP6')),
                    );
                  }
                } catch (e) {
                  if (c.mounted) {
                    ScaffoldMessenger.of(c).showSnackBar(
                      SnackBar(content: Text('تعذر الربط: $e')),
                    );
                  }
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('تسجيل الخروج'),
              onTap: () async {
                await sb.auth.signOut();
              },
            ),
          ],
        ),
      ),
    );
  }
}

class Printer {
  static Future<void> connect() async {
    await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
    ].request();

    final ds = await XprinterBluetooth.getBondedDevices();
    final d = ds
            .where((x) => (x.name ?? '').toUpperCase().contains('HP6'))
            .firstOrNull ??
        (ds.isNotEmpty ? ds.first : null);

    if (d == null) throw Exception('HP6 غير مقترنة');

    await XprinterConnection.connect(
      type: XprinterConnectionType.bluetooth,
      address: d.address,
    );
    await PosPrinter.initialize();
  }

  static Future<void> test() async {
    await connect();
    await PosPrinter.printText('SILVER ONE\n');
    await PosPrinter.printText('HP6 TEST\n');
    await PosPrinter.feedLine(3);
  }

  static Future<void> printLabel(
    String code,
    String name,
    double? weight,
  ) async {
    await connect();
    await PosPrinter.initialize();
    await PosPrinter.printText(
      'SILVER ONE\n',
      alignment: XprinterAlignment.center,
    );
    await PosPrinter.printBarCode(
      code,
      type: XprinterBarcodeType.code128,
      height: 70,
      width: 2,
      hri: XprinterBarcodeHri.below,
      alignment: XprinterAlignment.center,
    );
    await PosPrinter.printText(
      '$code\n',
      alignment: XprinterAlignment.center,
    );
    if (name.isNotEmpty) {
      await PosPrinter.printText(
        '$name\n',
        alignment: XprinterAlignment.center,
      );
    }
    if (weight != null) {
      await PosPrinter.printText(
        'الوزن: ${weight.toStringAsFixed(2)} غ\n',
        alignment: XprinterAlignment.center,
      );
    }
    await PosPrinter.feedLine(2);
  }
}
