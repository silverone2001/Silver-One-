# Silver One — تطبيق Android Native

هذه النسخة Native فعلية مبنية بـ Flutter، وليست WebView أو HTML-to-APK.

تشمل: Supabase، الفضة 6/5 د.أ، الساعات، العطور، العام، المخزون، البيع، الفواتير، التقارير، الكاميرا Native للباركود، وBluetooth Native لطابعة HP6.

## البناء

المشروع يحتوي GitHub Actions. ارفع المجلد إلى مستودع GitHub ثم شغّل Actions > Build Silver One APK. سيظهر ملف APK كـ Artifact.

ملاحظة: يجب أن تكون HP6 مقترنة أولاً من إعدادات Bluetooth في Android، ثم من Silver One اختر «ربط HP6».
