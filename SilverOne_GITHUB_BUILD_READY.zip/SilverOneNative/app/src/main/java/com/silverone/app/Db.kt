package com.silverone.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Db(ctx: Context): SQLiteOpenHelper(ctx,"silver_one.db",null,2){
 override fun onCreate(d: SQLiteDatabase){
  d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT UNIQUE, code TEXT UNIQUE, name TEXT, category TEXT, type TEXT, price REAL, weight REAL, qty INTEGER, deleted INTEGER DEFAULT 0)")
  d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT UNIQUE, invoice TEXT, product_code TEXT, qty INTEGER, total REAL, discount REAL, created INTEGER)")
  d.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT UNIQUE, note TEXT, amount REAL, created INTEGER)")
  d.execSQL("CREATE TABLE activity(id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT UNIQUE, action TEXT, created INTEGER)")
 }
 override fun onUpgrade(d:SQLiteDatabase,o:Int,n:Int){
  if(o<2){
   // Fresh project normally starts at v2. For safety, add UUID columns if upgrading an older local DB.
   try{d.execSQL("ALTER TABLE products ADD COLUMN uuid TEXT")}catch(_:Exception){}
   try{d.execSQL("ALTER TABLE products ADD COLUMN deleted INTEGER DEFAULT 0")}catch(_:Exception){}
   try{d.execSQL("ALTER TABLE sales ADD COLUMN uuid TEXT")}catch(_:Exception){}
   try{d.execSQL("ALTER TABLE expenses ADD COLUMN uuid TEXT")}catch(_:Exception){}
   try{d.execSQL("ALTER TABLE activity ADD COLUMN uuid TEXT")}catch(_:Exception){}
  }
 }
 fun addProduct(code:String,name:String,cat:String,type:String,price:Double,weight:Double,qty:Int){
  val v=ContentValues().apply{put("uuid",java.util.UUID.randomUUID().toString());put("code",code);put("name",name);put("category",cat);put("type",type);put("price",price);put("weight",weight);put("qty",qty)}
  writableDatabase.insertOrThrow("products",null,v); log("إضافة صنف $code")
 }
 fun deleteProduct(id:Long){val v=ContentValues().apply{put("deleted",1)};writableDatabase.update("products",v,"id=?",arrayOf(id.toString()));log("حذف صنف")}
 fun products():MutableList<Array<String>>{val out=mutableListOf<Array<String>>(); val c=readableDatabase.rawQuery("SELECT id,code,name,category,price,weight,qty FROM products WHERE deleted=0 ORDER BY id DESC",null); c.use{while(it.moveToNext())out.add(arrayOf(it.getString(0),it.getString(1),it.getString(2),it.getString(3),it.getDouble(4).toString(),it.getDouble(5).toString(),it.getInt(6).toString()))};return out}
 fun find(code:String)=readableDatabase.rawQuery("SELECT code,name,category,price,weight,qty FROM products WHERE code=?",arrayOf(code))
 fun sell(invoice:String,code:String,qty:Int,total:Double,discount:Double){writableDatabase.beginTransaction();try{writableDatabase.execSQL("UPDATE products SET qty=qty-? WHERE code=? AND qty>=?",arrayOf(qty,code,qty));val v=ContentValues().apply{put("uuid",java.util.UUID.randomUUID().toString());put("invoice",invoice);put("product_code",code);put("qty",qty);put("total",total);put("discount",discount);put("created",System.currentTimeMillis())};writableDatabase.insertOrThrow("sales",null,v);log("بيع $invoice");writableDatabase.setTransactionSuccessful()}finally{writableDatabase.endTransaction()}}
 fun addExpense(note:String,amount:Double){val v=ContentValues().apply{put("uuid",java.util.UUID.randomUUID().toString());put("note",note);put("amount",amount);put("created",System.currentTimeMillis())};writableDatabase.insert("expenses",null,v);log("مصروف")}
 fun salesTotal():Double{val c=readableDatabase.rawQuery("SELECT COALESCE(SUM(total-discount),0) FROM sales",null);c.use{it.moveToFirst();return it.getDouble(0)}}
 fun expensesTotal():Double{val c=readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM expenses",null);c.use{it.moveToFirst();return it.getDouble(0)}}
 fun log(a:String){val v=ContentValues().apply{put("uuid",java.util.UUID.randomUUID().toString());put("action",a);put("created",System.currentTimeMillis())};writableDatabase.insert("activity",null,v)}
 fun nextCode(prefix:String):String{var n=1; val c=readableDatabase.rawQuery("SELECT code FROM products WHERE code LIKE ? ORDER BY id DESC LIMIT 1",arrayOf("$prefix-%"));c.use{if(it.moveToFirst()){val s=it.getString(0).substringAfterLast('-');n=(s.toIntOrNull()?:0)+1}};return String.format("%s-%04d",prefix,n)}
}

fun productsJson(): org.json.JSONArray {
 val a=org.json.JSONArray(); val c=readableDatabase.rawQuery("SELECT uuid,code,name,category,type,price,weight,qty,deleted FROM products",null); c.use{while(it.moveToNext()){val o=org.json.JSONObject();o.put("uuid",it.getString(0));o.put("code",it.getString(1));o.put("name",it.getString(2));o.put("category",it.getString(3));o.put("type",it.getString(4));o.put("price",it.getDouble(5));o.put("weight",it.getDouble(6));o.put("qty",it.getInt(7));o.put("deleted",it.getInt(8));a.put(o)}};return a
}
fun salesJson(): org.json.JSONArray {
 val a=org.json.JSONArray(); val c=readableDatabase.rawQuery("SELECT uuid,invoice,product_code,qty,total,discount,created FROM sales",null); c.use{while(it.moveToNext()){val o=org.json.JSONObject();o.put("uuid",it.getString(0));o.put("invoice",it.getString(1));o.put("product_code",it.getString(2));o.put("qty",it.getInt(3));o.put("total",it.getDouble(4));o.put("discount",it.getDouble(5));o.put("created",it.getLong(6));a.put(o)}};return a
}
fun expensesJson(): org.json.JSONArray {
 val a=org.json.JSONArray(); val c=readableDatabase.rawQuery("SELECT uuid,note,amount,created FROM expenses",null); c.use{while(it.moveToNext()){val o=org.json.JSONObject();o.put("uuid",it.getString(0));o.put("note",it.getString(1));o.put("amount",it.getDouble(2));o.put("created",it.getLong(3));a.put(o)}};return a
}
fun mergeProducts(a: org.json.JSONArray){
 val d=writableDatabase; d.beginTransaction(); try{for(i in 0 until a.length()){val o=a.getJSONObject(i); val uuid=o.getString("uuid"); val v=ContentValues().apply{put("uuid",uuid);put("code",o.optString("code"));put("name",o.optString("name"));put("category",o.optString("category"));put("type",o.optString("type"));put("price",o.optDouble("price"));put("weight",o.optDouble("weight"));put("qty",o.optInt("qty"));put("deleted",o.optInt("deleted",0))}; val n=d.update("products",v,"uuid=?",arrayOf(uuid)); if(n==0) d.insertWithOnConflict("products",null,v,SQLiteDatabase.CONFLICT_IGNORE)}; d.setTransactionSuccessful()}finally{d.endTransaction()}
}
fun mergeSales(a: org.json.JSONArray){val d=writableDatabase;d.beginTransaction();try{for(i in 0 until a.length()){val o=a.getJSONObject(i);val v=ContentValues().apply{put("uuid",o.getString("uuid"));put("invoice",o.optString("invoice"));put("product_code",o.optString("product_code"));put("qty",o.optInt("qty"));put("total",o.optDouble("total"));put("discount",o.optDouble("discount"));put("created",o.optLong("created"))};d.insertWithOnConflict("sales",null,v,SQLiteDatabase.CONFLICT_IGNORE)};d.setTransactionSuccessful()}finally{d.endTransaction()}}
fun mergeExpenses(a: org.json.JSONArray){val d=writableDatabase;d.beginTransaction();try{for(i in 0 until a.length()){val o=a.getJSONObject(i);val v=ContentValues().apply{put("uuid",o.getString("uuid"));put("note",o.optString("note"));put("amount",o.optDouble("amount"));put("created",o.optLong("created"))};d.insertWithOnConflict("expenses",null,v,SQLiteDatabase.CONFLICT_IGNORE)};d.setTransactionSuccessful()}finally{d.endTransaction()}}
