package com.silverone.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import java.io.OutputStream
import java.util.UUID

class Printer(private val ctx:Context){
 private val uuid=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
 fun paired():List<BluetoothDevice>{val a=BluetoothAdapter.getDefaultAdapter()?:return emptyList(); if(android.os.Build.VERSION.SDK_INT>=31&&ActivityCompat.checkSelfPermission(ctx,Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)return emptyList();return a.bondedDevices.toList()}
 fun print(device:BluetoothDevice,text:String,barcode:String){
  if(android.os.Build.VERSION.SDK_INT>=31&&ActivityCompat.checkSelfPermission(ctx,Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)throw SecurityException("Bluetooth permission required")
  val s=device.createRfcommSocketToServiceRecord(uuid);s.connect();val o=s.outputStream; val cmd="SIZE 15 mm,10 mm\nGAP 2 mm,0 mm\nCLS\nTEXT 10,10,\"3\",0,1,1,\"$text\"\nBARCODE 10,35,\"128\",30,1,0,2,2,\"$barcode\"\nPRINT 1\n";o.write(cmd.toByteArray(Charsets.UTF_8));o.flush();o.close();s.close()
 }
}
