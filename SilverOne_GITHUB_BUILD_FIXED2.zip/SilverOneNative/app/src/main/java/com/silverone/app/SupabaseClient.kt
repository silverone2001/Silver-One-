package com.silverone.app

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

class SupabaseClient(private val baseUrl: String, private val anonKey: String, private var accessToken: String) {
    private fun request(method: String, path: String, body: String? = null): String {
        val conn = (URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection)
        conn.requestMethod = method
        conn.setRequestProperty("apikey", anonKey)
        conn.setRequestProperty("Authorization", "Bearer $accessToken")
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Accept", "application/json")
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Prefer", "resolution=merge-duplicates,return=minimal")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("Supabase HTTP $code")
        return text
    }
    fun upsert(table: String, rows: JSONArray) { if (rows.length() > 0) request("POST", "/rest/v1/$table?on_conflict=uuid", rows.toString()) }
    fun fetch(table: String): JSONArray = JSONArray(request("GET", "/rest/v1/$table?select=*"))
}
