package com.silverone.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AuthClient(private val baseUrl: String, private val anonKey: String) {
    data class Session(val accessToken: String, val refreshToken: String, val email: String)

    fun signIn(email: String, password: String): Session {
        val body = JSONObject().put("email", email).put("password", password).toString()
        val c = (URL(baseUrl.trimEnd('/') + "/auth/v1/token?grant_type=password").openConnection() as HttpURLConnection)
        c.requestMethod = "POST"
        c.doOutput = true
        c.setRequestProperty("apikey", anonKey)
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        if (code !in 200..299) throw IllegalStateException("تسجيل الدخول فشل")
        val j = JSONObject(text)
        return Session(j.getString("access_token"), j.getString("refresh_token"), j.optString("user_email", email))
    }
}
