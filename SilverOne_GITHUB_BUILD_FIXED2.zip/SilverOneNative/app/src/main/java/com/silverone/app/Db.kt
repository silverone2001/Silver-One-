package com.silverone.app

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import java.text.SimpleDateFormat
import java.util.*

class MainActivity:AppCompatActivity(){
 private lateinit var db:Db; private val prefs by lazy { getSharedPreferences("silver_one", MODE_PRIVATE) }; private val baseUrl="https://pkhxvxjtxkzdujpppnmj.supabase.co"; private val anonKey="sb_publishable_lVBLKTFPy9atxKOzb-gDKQ_VXpQNQM1"; private var cloud: SupabaseClient?=null; private val gold=0xffc99a3e.toInt(); private var scanTarget:EditText?=null
 private val scanner=registerForActivityResult(ScanContract()){r-> if(r.contents!=null)scanTarget?.setText(r.contents)}
 override fun onCreate(b:Bundle?){super.onCreate(b);db=Db(this); val token=prefs.getString("access_token",null); if(token!=null) cloud=SupabaseClient(baseUrl,anonKey,token); if(Build.VERSION.SDK_INT>=31)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN),10); if(cloud==null) showLogin() else showHome()}
 private fun showLogin(){
  val l=root("Silver One — تسجيل الدخول");
  l.addView(TextView(this).apply{text="حساب المدير";textSize=20f;gravity=17;setPadding(0,20,0,20)})
  val user=EditText(this).apply{hint="اسم المستخدم / البريد الإلكتروني";inputType=1}
  val pass=EditText(this).apply{hint="كلمة المرور";inputType=0x81}
  l.addView(user);l.addView(pass)
  l.addView(btn("دخول"){ val u=user.text.toString().trim(); val pw=pass.text.toString(); if(u.isEmpty()||pw.isEmpty()){Toast.makeText(this,"أدخلي اسم المستخدم وكلمة المرور",Toast.LENGTH_LONG).show();return@btn}; Toast.makeText(this,"جاري تسجيل الدخول...",Toast.LENGTH_SHORT).show(); Thread{try{val sess=AuthClient(baseUrl,anonKey).signIn(u,pw); prefs.edit().putString("access_token",sess.accessToken).putString("refresh_token",sess.refreshToken).apply(); cloud=SupabaseClient(baseUrl,anonKey,sess.accessToken); runOnUiThread{showHome()}}catch(e:Exception){runOnUiThread{Toast.makeText(this,"اسم المستخدم أو كلمة المرور غير صحيحة",Toast.LENGTH_LONG).show()}}}.start()})
 }

 private fun root(title:String="Silver One"):LinearLayout{val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(20,20,20,20);l.setBackgroundColor(0xfffaf8f3.toInt()); val h=TextView(this);h.text=title;h.textSize=25f;h.setTypeface(null,Typeface.BOLD);h.gravity=Gravity.CENTER;h.setTextColor(gold);l.addView(h,LinearLayout.LayoutParams(-1,70));return l}
 private fun btn(t:String,on:()->Unit):Button=Button(this).apply{text=t;textSize=17f;setOnClickListener{on()};setTextColor(0xff202020.toInt())}
 private fun showHome(){val l=root();l.addView(TextView(this).apply{text="SILVER ONE\nJewelry • Watches • Perfumes • More";textSize=18f;gravity=17;setPadding(0,10,0,20)}); val grid=LinearLayout(this);grid.orientation=LinearLayout.VERTICAL; val rows=listOf(listOf("🥈 الفضة" to {showProducts("فضة")},"⌚ الساعات" to {showProducts("ساعات")}),listOf("🌸 العطور" to {showProducts("عطور")},"🧾 العام" to {showProducts("عام")}));rows.forEach{r->val row=LinearLayout(this);r.forEach{(t,f)->row.addView(btn(t,f),LinearLayout.LayoutParams(0,100,1f).apply{setMargins(6,6,6,6)})};grid.addView(row)};l.addView(grid);l.addView(btn("💰 المبيعات"){showSales()});l.addView(btn("📊 التقارير"){showReports()});l.addView(btn("🧾 الفواتير / طباعة"){showInvoices()});l.addView(btn("☁️ مزامنة البيانات مع السحابة"){syncCloud()});l.addView(btn("⚙️ الإعدادات / طابعة HP6"){showSettings()});setContentView(l)}

 private fun syncCloud(){
  Toast.makeText(this,"جاري مزامنة البيانات...",Toast.LENGTH_SHORT).show()
  Thread { try {
   cloud!!.upsert("products",db.productsJson()); cloud!!.upsert("sales",db.salesJson()); cloud!!.upsert("expenses",db.expensesJson())
   db.mergeProducts(cloud!!.fetch("products")); db.mergeSales(cloud!!.fetch("sales")); db.mergeExpenses(cloud!!.fetch("expenses"))
   runOnUiThread{Toast.makeText(this,"تمت مزامنة البيانات بنجاح ✓",Toast.LENGTH_LONG).show();if(cloud==null) showLogin() else showHome()}
  } catch(e:Exception){runOnUiThread{Toast.makeText(this,"فشلت المزامنة: ${e.message}",Toast.LENGTH_LONG).show()}} }.start()
 }
 private fun showProducts(cat:String){val l=root(cat);l.addView(btn("＋ إضافة صنف"){showAdd(cat)});val scroll=ScrollView(this);val box=LinearLayout(this);box.orientation=LinearLayout.VERTICAL;db.products().filter{it[3]==cat}.forEach{p->val row=LinearLayout(this);row.orientation=LinearLayout.VERTICAL;row.setPadding(10,10,10,10);row.addView(TextView(this).apply{text="${p[1]} — ${p[2]}\nالسعر: ${p[4]} JD | الوزن: ${p[5]} g | الكمية: ${p[6]}";textSize=16f});val del=btn("حذف"){db.deleteProduct(p[0].toLong());showProducts(cat)};row.addView(del);box.addView(row)};scroll.addView(box);l.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));l.addView(btn("← رجوع"){if(cloud==null) showLogin() else showHome()});setContentView(l)}
 private fun showAdd(cat:String){val l=root("إضافة صنف — $cat");val name=EditText(this).apply{hint="اسم الصنف"};val type=EditText(this).apply{hint="النوع (ستاتي / رجالي / ... )"};val price=EditText(this).apply{hint="السعر JD";inputType=2};val weight=EditText(this).apply{hint="الوزن (gram)";inputType=2};val qty=EditText(this).apply{hint="الكمية";inputType=2};val code=EditText(this).apply{hint="الكود";setText(db.nextCode(if(cat=="فضة")"SV" else if(cat=="ساعات")"WT" else if(cat=="عطور")"PF" else "GN"))};scanTarget=code;val scan=btn("📷 مسح باركود"){scanner.launch(ScanOptions().apply{setPrompt("وجّه الكاميرا إلى الباركود");setBeepEnabled(true);setOrientationLocked(true)})};l.addView(name);l.addView(type);l.addView(price);l.addView(weight);l.addView(qty);l.addView(code);l.addView(scan);l.addView(btn("حفظ الصنف"){try{var pr=price.text.toString().toDouble();if(cat=="فضة"){val grams=weight.text.toString().toDouble();val t=type.text.toString();pr=grams*if(t.contains("ستاتي"))6.0 else if(t.contains("رجالي"))5.0 else pr};db.addProduct(code.text.toString(),name.text.toString(),cat,type.text.toString(),pr,weight.text.toString().toDoubleOrNull()?:0.0,qty.text.toString().toIntOrNull()?:1);Toast.makeText(this,"تم حفظ الصنف",Toast.LENGTH_SHORT).show();showProducts(cat)}catch(e:Exception){Toast.makeText(this,"تحقق من البيانات: ${e.message}",Toast.LENGTH_LONG).show()}});l.addView(btn("← رجوع"){showProducts(cat)});setContentView(l)}
 private fun showSales(){val l=root("بيع جديد");val code=EditText(this).apply{hint="كود الصنف"};val q=EditText(this).apply{hint="الكمية";inputType=2};val discount=EditText(this).apply{hint="الخصم JD";inputType=2};scanTarget=code;l.addView(code);l.addView(btn("📷 مسح الكود"){scanner.launch(ScanOptions())});l.addView(q);l.addView(discount);l.addView(btn("إتمام البيع"){val c=code.text.toString();val cur=db.find(c);if(cur.moveToFirst()){val price=cur.getDouble(3);val qty=q.text.toString().toIntOrNull()?:1;val dis=discount.text.toString().toDoubleOrNull()?:0.0;val total=price*qty;val inv="INV-"+System.currentTimeMillis().toString().takeLast(6);db.sell(inv,c,qty,total,dis);Toast.makeText(this,"تم البيع: $inv — ${total-dis} JD",Toast.LENGTH_LONG).show()}else Toast.makeText(this,"الصنف غير موجود",Toast.LENGTH_LONG).show();cur.close()});l.addView(btn("← رجوع"){if(cloud==null) showLogin() else showHome()});setContentView(l)}
 private fun showReports(){val l=root("التقارير");val s=db.salesTotal();val e=db.expensesTotal();l.addView(TextView(this).apply{text="إجمالي المبيعات: %.2f JD\nالمصروفات: %.2f JD\nصافي المبيعات: %.2f JD".format(Locale.US,s,e,s-e);textSize=21f;setPadding(10,30,10,30)});l.addView(btn("← رجوع"){if(cloud==null) showLogin() else showHome()});setContentView(l)}
 private fun showInvoices(){val l=root("الفواتير");l.addView(TextView(this).apply{text="الفواتير محفوظة داخل قاعدة بيانات التطبيق.\nيمكن ربط الطباعة من إعدادات HP6.";textSize=18f});l.addView(btn("← رجوع"){if(cloud==null) showLogin() else showHome()});setContentView(l)}
 private fun showSettings(){val l=root("الإعدادات");l.addView(TextView(this).apply{text="طابعة Xprinter HP6\nBluetooth + TSPL";textSize=20f});l.addView(btn("🔎 اختبار اتصال HP6"){showPrinters()});l.addView(btn("← رجوع"){if(cloud==null) showLogin() else showHome()});setContentView(l)}
 private fun showPrinters(){val p=Printer(this);val l=root("اختيار طابعة HP6");val devices=p.paired();if(devices.isEmpty())l.addView(TextView(this).apply{text="لا توجد طابعة مقترنة. من إعدادات Bluetooth في الهاتف، اقترني بـ HP6 أولاً ثم عودي للتطبيق.";textSize=18f});devices.forEach{d->l.addView(btn("${d.name} — ${d.address}"){try{p.print(d,"SILVER ONE", "SV-TEST-0001");Toast.makeText(this,"تم إرسال اختبار الطباعة",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(this,"فشل الاتصال: ${e.message}",Toast.LENGTH_LONG).show()}})};l.addView(btn("← رجوع"){showSettings()});setContentView(l)}
 private fun LinearLayout.padding(a:Int,b:Int,c:Int,d:Int){setPadding(a,b,c,d)}
}
