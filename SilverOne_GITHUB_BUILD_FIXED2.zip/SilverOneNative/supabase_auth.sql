-- Run after the base schema. Supabase Auth handles passwords securely.
-- The app signs in with the existing Auth users; no new users are created by this script.

alter table public.products enable row level security;
alter table public.sales enable row level security;
alter table public.expenses enable row level security;

drop policy if exists "products anon all" on public.products;
drop policy if exists "sales anon all" on public.sales;
drop policy if exists "expenses anon all" on public.expenses;
drop policy if exists "products authenticated all" on public.products;
drop policy if exists "sales authenticated all" on public.sales;
drop policy if exists "expenses authenticated all" on public.expenses;

create policy "products authenticated all" on public.products
for all to authenticated using (true) with check (true);
create policy "sales authenticated all" on public.sales
for all to authenticated using (true) with check (true);
create policy "expenses authenticated all" on public.expenses
for all to authenticated using (true) with check (true);
