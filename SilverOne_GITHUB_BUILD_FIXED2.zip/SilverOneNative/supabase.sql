-- Silver One Supabase schema
create extension if not exists pgcrypto;

create table if not exists public.products (
  uuid uuid primary key,
  code text unique not null,
  name text not null,
  category text not null,
  type text default '',
  price numeric not null default 0,
  weight numeric not null default 0,
  qty integer not null default 0,
  deleted integer not null default 0
);
create table if not exists public.sales (
  uuid uuid primary key,
  invoice text not null,
  product_code text not null,
  qty integer not null,
  total numeric not null default 0,
  discount numeric not null default 0,
  created bigint not null
);
create table if not exists public.expenses (
  uuid uuid primary key,
  note text not null,
  amount numeric not null default 0,
  created bigint not null
);

alter table public.products enable row level security;
alter table public.sales enable row level security;
alter table public.expenses enable row level security;

drop policy if exists "products anon all" on public.products;
drop policy if exists "sales anon all" on public.sales;
drop policy if exists "expenses anon all" on public.expenses;
create policy "products anon all" on public.products for all to anon using (true) with check (true);
create policy "sales anon all" on public.sales for all to anon using (true) with check (true);
create policy "expenses anon all" on public.expenses for all to anon using (true) with check (true);
