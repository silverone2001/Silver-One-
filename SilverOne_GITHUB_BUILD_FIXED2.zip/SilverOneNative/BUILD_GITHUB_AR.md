# بناء Silver One من الهاتف عبر GitHub

1. أنشئ مستودعًا جديدًا على GitHub.
2. ارفع محتويات مجلد SilverOneNative إلى المستودع.
3. افتح تبويب Actions.
4. اختر Build Silver One APK.
5. اضغط Run workflow.
6. بعد نجاح البناء افتح التشغيل الناجح ثم Artifacts.
7. نزّل SilverOne-debug-apk ثم فك الضغط وثبّت app-debug.apk.

هذا المشروع يستخدم Gradle 8.7 وJDK 17 في GitHub Actions، ولا يحتاج إلى Android Studio على الهاتف.
